from django.urls import path
from . import views

urlpatterns = [
    # API 路由
    path('api/start/', views.start_game, name='start_game'),
    path('api/guess/', views.guess_number, name='guess_number'),
    path('api/reset/', views.reset_game, name='reset_game'),

    # 页面路由
    path('', views.game_page, name='game_page'),  # 访问 /game/ 时显示页面
]