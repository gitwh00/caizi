from django.shortcuts import render
from django.http import JsonResponse
import random

# 游戏状态存储（实际项目建议用 Session 或数据库）
game_state = {
    'target_number': random.randint(1, 100),
    'attempts': 0,
}

def start_game(request):
    """开始新游戏"""
    game_state['target_number'] = random.randint(1, 100)
    game_state['attempts'] = 0
    return JsonResponse({
        'message': '新游戏开始！猜一个1到100之间的数字。',
        'attempts': game_state['attempts'],
    })

def guess_number(request):
    """提交猜测"""
    try:
        guess = int(request.GET.get('guess'))
    except (TypeError, ValueError):
        return JsonResponse({'error': '请输入有效的数字！'}, status=400)

    game_state['attempts'] += 1

    if guess < game_state['target_number']:
        result = {
            'hint': '猜低了！',
            'type': 'low'
        }
    elif guess > game_state['target_number']:
        result = {
            'hint': '猜高了！',
            'type': 'high'
        }
    else:
        result = {
            'hint': f'恭喜！你在 {game_state["attempts"]} 次尝试中猜对了！',
            'type': 'correct'
        }

    return JsonResponse({
        'result': result['hint'],
        'attempts': game_state['attempts'],
        'detail': result,
    })

def reset_game(request):
    """重置游戏"""
    game_state['target_number'] = random.randint(1, 100)
    game_state['attempts'] = 0
    return JsonResponse({'message': '游戏已重置，开始新的挑战吧！'})

# 新增 game_page 视图函数
def game_page(request):
    """返回游戏页面"""
    return render(request, 'game/game.html')  # 确保模板路径正确